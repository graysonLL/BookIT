/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        white: "#fff",
        royalblue: "#2670ff",
        black: "#000",
        deepskyblue: "#3ab3f7",
        st1: "#212832",
        gray: {
          "100": "#7c7c7c",
          "200": "rgba(0, 0, 0, 0.34)",
        },
        blanchedalmond: "#ffe9c9",
        gainsboro: "rgba(217, 217, 217, 0.68)",
        st: "#181e4b",
        slategray: "#5e6282",
        salmon: "#df6951",
        whitesmoke: "#efefef",
      },
      spacing: {},
      fontFamily: {
        aleo: "Aleo",
        baumans: "Baumans",
        "anek-bangla": "'Anek Bangla'",
        "barlow-condensed": "'Barlow Condensed'",
        volkhov: "Volkhov",
        poppins: "Poppins",
      },
      borderRadius: {
        "8xs": "5px",
        "2xl": "21px",
        mid: "17px",
      },
    },
    fontSize: {
      lg: "18px",
      xl: "20px",
      base: "16px",
      mid: "17px",
      "51xl": "70px",
      "9xl": "28px",
      "17xl": "36px",
      "13xl": "32px",
      "29xl": "48px",
      "5xl": "24px",
      "11xl": "30px",
      "7xl": "26px",
      "41xl": "60px",
      inherit: "inherit",
    },
  },
  corePlugins: {
    preflight: false,
  },
};
