const ReserveButton = () => {
  return (
    <div className="absolute top-[224px] left-[494px] w-[172px] h-[49px] text-left text-7xl text-st1 font-anek-bangla">
      <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] rounded-2xl bg-blanchedalmond" />
      <div className="absolute top-[0%] left-[24.42%]">Reserve</div>
    </div>
  );
};

export default ReserveButton;
