const SignUp = () => {
  return (
    <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] rounded-8xs box-border border-[1px] border-solid border-st1" />
  );
};

export default SignUp;
