const ReserveButton1 = () => {
  return (
    <div className="absolute top-[213px] left-[472px] w-[169.2px] h-[49px] text-left text-7xl text-st1 font-anek-bangla">
      <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] rounded-2xl bg-blanchedalmond" />
      <div className="absolute w-[52.01%] top-[0%] left-[24.23%] inline-block">
        Reserve
      </div>
    </div>
  );
};

export default ReserveButton1;
