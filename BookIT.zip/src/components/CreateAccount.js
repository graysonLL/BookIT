const CreateAccount = () => {
  return (
    <div className="absolute top-[785px] left-[586px] w-[267.4px] h-[41px] text-center text-xl text-white font-aleo">
      <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] bg-deepskyblue shadow-[0px_4px_4px_rgba(0,_0,_0,_0.6)]" />
      <b className="absolute top-[21.95%] left-[14.58%]">Create your Account</b>
    </div>
  );
};

export default CreateAccount;
