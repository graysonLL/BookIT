const Button = () => {
  return (
    <div className="absolute top-[18px] left-[1065px] w-[102px] h-10 text-center text-mid text-st1 font-aleo">
      <b className="absolute top-[22.5%] left-[29.41%]">{`Login `}</b>
      <img
        className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] rounded-8xs max-w-full overflow-hidden max-h-full"
        alt=""
        src="/rectangle-4.svg"
      />
    </div>
  );
};

export default Button;
