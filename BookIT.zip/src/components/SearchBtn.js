const SearchBtn = () => {
  return (
    <div className="absolute top-[7px] left-[481px] w-[249px] h-[79px] text-left text-17xl text-st1 font-anek-bangla">
      <div className="absolute h-full w-full top-[0%] right-[0%] bottom-[0%] left-[0%] rounded-2xl bg-blanchedalmond box-border border-[1px] border-solid border-black" />
      <div className="absolute top-[7.59%] left-[29.32%]">Search</div>
    </div>
  );
};

export default SearchBtn;
