import SignUp from "../components/SignUp";

const Homepage = () => {
  return (
    <div className="w-full relative bg-white h-[1023px] overflow-hidden text-left text-13xl text-st1 font-aleo">
      <div className="absolute top-[-94px] left-[-427px] w-[1922.3px] h-[1079px]">
        <img
          className="absolute top-[0px] left-[0px] w-[1922.3px] h-[872.6px]"
          alt=""
          src="/decore.svg"
        />
        <div className="absolute top-[199px] left-[1301px] w-[484.6px] h-[64.7px]">
          <div className="absolute top-[11px] left-[197px] w-[81px] h-[38px]">
            <div className="absolute top-[0%] left-[0%]">Login</div>
          </div>
          <div className="absolute top-[11px] left-[0px] w-[132px] h-[38px]">
            <div className="absolute top-[0%] left-[0%]">Bookings</div>
          </div>
          <div className="absolute top-[0px] left-[339px] w-[145.6px] h-[64.7px]">
            <b className="absolute h-[55.64%] w-[74.86%] top-[18.55%] left-[12.36%] inline-block">
              Sign up
            </b>
            <SignUp />
          </div>
        </div>
        <div className="absolute top-[315px] left-[571px] w-[1178px] h-[764px] text-xl text-salmon font-poppins">
          <div className="absolute top-[125px] left-[0px] w-[676px] h-[423px]">
            <b className="absolute top-[0px] left-[0px] uppercase whitespace-pre-wrap">{`yOUR NUMBER ONE  LOUNGE SPOT `}</b>
            <div className="absolute top-[333px] left-[1px] text-base leading-[30px] font-medium text-slategray inline-block w-[477px]">
              A chic urban retreat, our hotel offers a perfect fusion of
              contemporary elegance and warm hospitality for an unforgettable
              stay.
            </div>
            <img
              className="absolute top-[103px] left-[310px] w-[261px] h-4"
              alt=""
              src="/decore.svg"
            />
            <b className="absolute top-[47px] left-[0px] text-41xl tracking-[-0.04em] leading-[89px] font-volkhov text-st">
              <p className="m-0">{`Experience luxury, `}</p>
              <p className="m-0">comfort, and impeccable</p>
              <p className="m-0">hospitality at our hotel.</p>
            </b>
          </div>
          <img
            className="absolute top-[0px] left-[413px] w-[765px] h-[764px] object-cover"
            alt=""
            src="/image@2x.png"
          />
        </div>
      </div>
      <div className="absolute top-[103px] left-[145px] w-52 h-[83px] text-51xl text-black font-baumans">
        <div className="absolute top-[34px] left-[49px] rounded-[50%] [background:linear-gradient(#ff9254,_#ff9254),_linear-gradient(#ff9254,_#ff9254),_#ff9254] w-[29px] h-[29px]" />
        <div className="absolute top-[34px] left-[90px] rounded-[50%] [background:linear-gradient(#ff9254,_#ff9254),_linear-gradient(#ff9254,_#ff9254),_#ff9254] w-[29px] h-[29px]" />
        <div className="absolute top-[0px] left-[0px]">BookIT</div>
      </div>
    </div>
  );
};

export default Homepage;
